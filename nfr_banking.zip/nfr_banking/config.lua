Config = {}
   -- COORDONATE 
   Config.ATMs = {
     vector3(149.8096, -1040.697, 29.37407)
   }
